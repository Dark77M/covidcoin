import readlineSync from 'readline-sync'
import {MOSAIC_NAME} from './wallet'
import { async } from 'hasha';
import {loadWallet} from './storage';
import {getBalance, createAccount,testTransaction} from './wallet';

const Cfont = require('cfonts');
const clear = require('clear');
var colors = require('colors/safe');

async function cmdBalance(){
    const wallet = await loadWallet();
    await getBalance(wallet.address);

    loadCli()

}

function cndCreatAccount(){
createAccount();
loadCli()
}

async function cmdSendCoins(){
    await testTransaction();
loadCli()
}

function loadCli(){
    setTimeout(() => {
        back();
    }, 1000);
    
}

async function back(){
    if (readlineSync.keyInYN('go back?')){
    cli();
} else {
    process.exit();
}
}



const enum Commands {
    create = 'CREATE',
    balance = 'BALANCE',
    transaction = 'TRANSACTION',
    close = 'CLOSE',
}


export function cli() {
    clear();

    Cfont.say(`COVIDCOIND`, {gradient: 'blue,red', align:'center'});

    console.log(colors.blue.underline(`Command line Interface for ${MOSAIC_NAME} power by Ali & Martina`));

 
    var menu = require('readline-sync'),
    Command = [
        Commands.create,
        Commands.transaction,
        Commands.balance,
        Commands.close

    ],

        index = menu.keyInSelect(Command, 'Commands');

    switch (Command[index]){
     case Commands.create:
         cndCreatAccount();
        break;
     case Commands.transaction:
         cmdSendCoins();
        break;
     case Commands.balance:
         cmdBalance();
         break;
     case Commands.close:
         process.exit()
        break;
      default:
          cli();
          break;   
    }
    
};